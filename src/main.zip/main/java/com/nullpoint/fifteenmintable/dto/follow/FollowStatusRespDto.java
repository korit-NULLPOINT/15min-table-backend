package com.nullpoint.fifteenmintable.dto.follow;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FollowStatusRespDto {
    private boolean isFollowing;
}
