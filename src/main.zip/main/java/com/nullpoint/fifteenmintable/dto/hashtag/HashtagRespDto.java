package com.nullpoint.fifteenmintable.dto.hashtag;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class HashtagRespDto {
    private Integer hashtagId;
    private String name;
}
