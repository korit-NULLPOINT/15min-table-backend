package com.nullpoint.fifteenmintable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FifteenTableBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(FifteenTableBackendApplication.class, args);
    }

}
